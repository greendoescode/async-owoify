class NotAValidNumber(Exception):
    pass
